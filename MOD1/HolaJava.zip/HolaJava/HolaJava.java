public class HolaJava {
   public static void main(String[] args) {
       System.out.println("Hola Java desde campusMVP");
   }
}