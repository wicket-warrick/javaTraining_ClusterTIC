package derivacionobject;

class Aplicacion {
    void muestra(Punto objeto) {
        System.out.println(objeto);
    }
    
    void muestra(Object objeto) {
        if (objeto instanceof Circulo)
            System.out.println("Es un círculo");
        else if (objeto instanceof Punto)
            System.out.println("Es un punto");
    }
    
    void run() {
        var unPunto = new Punto(10L, 12L, 3L);
        var unCirculo = new Circulo(2L, 6L, 14L, 10L);
        
        unCirculo.desplaza(3L, -2L, -4L); // Método heredado de Punto
        
        System.out.println(unPunto + "\n" + unCirculo);
        
        // Conversiones
        //unCirculo = (Circulo ) unPunto;  // ClassCastException
        
        unPunto = (Punto ) unCirculo;
        System.out.println("Conversión a Punto: " + unPunto);
        
        // Conversión implícita al pasar como parámetro una referencia a objeto
        muestra(unCirculo);
        muestra(new Punto(1L, 2L, 3L));
        
        // Conversión explícita para invocar a una versión concreta
        muestra((Object ) unCirculo);
                
       
        // Comprobación de toString(), valueOf(), equals() y hashCode()
        Punto copiaPunto = Punto.valueOf(unPunto.toString()),
              otroPunto = (Punto ) unCirculo;
        
        System.out.println(
                "copiaPunto = " + copiaPunto + "\n" +
                "otroPunto = " + otroPunto + "\n" +
                "copiaPunto == otroPunto = " + (copiaPunto == otroPunto) + "\n" +
                "copiaPunto equals otroPunto = " + copiaPunto.equals(otroPunto) + "\n" +
                "hash de copiaPunto = " + copiaPunto.hashCode() + "\n" + 
                "hash de otroPunto = " + otroPunto.hashCode());        
    }
}

public class DerivacionObject {

    public static void main(String[] args) {
        (new Aplicacion()).run();
    }
    
}
