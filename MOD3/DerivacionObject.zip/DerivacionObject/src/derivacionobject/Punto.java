package derivacionobject;

import java.util.Objects;

public class Punto {
    private Long posX, posY, posZ;

    // El constructor precisa las coordenadas 3D del punto
    public Punto(Long x, Long y, Long z) {
        posX = x;
        posY = y;
        posZ = z;
    }
    
    // Método para desplazar el punto en el espacio
    public void desplaza(Long dx, Long dy, Long dz) {
        posX += dx;
        posY += dy;
        posZ += dz;
    }
    
    // Construye el punto a partir de la información alojada en la cadena
    public Punto(String stringValue) {
        int begin = stringValue.indexOf('{') + 1,
            end   = stringValue.indexOf('}') ;
        
        String[] values = stringValue
                    .substring(begin, end)
                    .split(",");
        
        posX = Long.valueOf(values[0]);
        posY = Long.valueOf(values[1]);
        posZ = Long.valueOf(values[2]);
    }

    // Método que convierte un objeto Punto en un String
    @Override
    public String toString() {
        return getClass().getSimpleName() + 
                "{" + posX + "," + posY + "," + posZ + "}";
    }
    
    // Método que genera un objeto Punto a partir de un String
    static public Punto valueOf(String stringValue) {
        return new Punto(stringValue);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj != null && obj instanceof Punto) {
            Punto p = (Punto ) obj;
            
            return p.posX.equals(this.posX) &&
                   p.posY.equals(this.posY) &&
                   p.posZ.equals(this.posZ);
        } 
        
        return false;             
    }

    @Override
    public int hashCode() {
        return Objects.hash(posX, posY, posZ);
    }
   
    /**
     * @return the posX
     */
    public Long getPosX() {
        return posX;
    }

    /**
     * @param posX the posX to set
     */
    public void setPosX(Long posX) {
        this.posX = posX;
    }

    /**
     * @return the posY
     */
    public Long getPosY() {
        return posY;
    }

    /**
     * @param posY the posY to set
     */
    public void setPosY(Long posY) {
        this.posY = posY;
    }

    /**
     * @return the posZ
     */
    public Long getPosZ() {
        return posZ;
    }

    /**
     * @param posZ the posZ to set
     */
    public void setPosZ(Long posZ) {
        this.posZ = posZ;
    }
}
