package derivacionobject;

public class Circulo extends Punto {
    private Long radio;
    
    public Circulo(Long x, Long y, Long z, Long r) {
        super(x, y, z);  // Invocar al constructor de la superclase
        radio = r;
    }

    @Override
    public String toString() {
        return super.toString() + ", " + radio;
    }    
    
    /**
     * @return the radio
     */
    public Long getRadio() {
        return radio;
    }

    /**
     * @param radio the radio to set
     */
    public void setRadio(Long radio) {
        this.radio = radio;
    }
}
