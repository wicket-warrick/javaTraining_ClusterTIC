package clasesanidadas;

public class Poligono {
    // Clase anidada para gestionar un vértice
    static public class Vertice { 
        private int x, y;
        
        public Vertice(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
    
    // Atributos y métodos de la clase externa
    private Vertice[] vertices;
    
    public Poligono(Vertice... vertices) {
        this.vertices = vertices;
    }
}
