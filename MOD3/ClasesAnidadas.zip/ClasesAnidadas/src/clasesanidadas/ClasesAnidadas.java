package clasesanidadas;

import java.math.BigDecimal;

/**
 * Clase principal de la Aplicación que demuestra el uso de clases anidadas,
 * tanto una clase interna como una clase anidada estática, y la insercción de
 * documentación
 *
 * @author Francisco Charte
 * @version 1.0
 * @see Factura
 * @see Factura.Linea
 */
public class ClasesAnidadas {

    /**
     * Punto de entrada a la aplicación
     *
     * @param args
     */
    public static void main(String[] args) {
        (new Aplicacion()).run();
    }
}

class Aplicacion {

    public void run() {
        var f = new Factura();
        Factura.Linea l;
        
        l = f.new Linea("Caja discos", 2, BigDecimal.valueOf(10.5));
        System.out.println(l);
        f.anadeLinea(l);
        f.anadeLinea("Conector USB", 1, BigDecimal.valueOf(8.45));
        System.out.println(f);
        
        var ticket // Aquí la inferencia de tipos detecta el tipo anidado
                = new Factura.Ticket(
                        "Discos,Conector",
                        new BigDecimal[]{new BigDecimal("10.5"), BigDecimal.valueOf(8.45)}
                );
        System.out.println(ticket);
    }
}
