package clasesanidadas;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Gestiona la información relativa a una factura
 * 
 * @author Francisco Charte
 * @version 1.0
 * @since Aug 2016
 * @see Factura.Linea
 */
public class Factura {
    /**
     * Fija el número máximo de líneas de una factura. Su valor por defecto es {@value}
     */
    public static final int MAX_LINEAS_FACTURA = 10;
    private static int siguienteNumero = 1;

    private Date fecha;
    private int numero;
    private BigDecimal importe;
    private Linea[] lineasFactura;
    private int numLineasFactura;

    /**
     * @return the fecha
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the importe
     */
    public BigDecimal getImporte() {
        return importe;
    }

    /**
     * @param importe the importe to set
     */
    public void setImporte(BigDecimal importe) {
        this.importe = importe;
    }

    /**
     * @return the lineasFactura
     */
    public Linea[] getLineasFactura() {
        return lineasFactura;
    }

    /**
     * @param lineasFactura the lineasFactura to set
     */
    public void setLineasFactura(Linea[] lineasFactura) {
        this.lineasFactura = lineasFactura;
    }
    
    
     /**
     * Representa cada una de las líneas que conforman una factura
     * 
     * @author Francisco Charte
     * @version 1.0
     * @since Aug 2016
     * @see Factura
     */
   public class Linea {
        private int numero;
        private String concepto;
        private int unidades;
        private BigDecimal precio;
       
        /**
         * El constructor genera una nueva línea de factura a partir de la información
         * aportada como entrada
         * 
         * @param c El concepto de la línea
         * @param u El número de unidades
         * @param p El importe unitario
         */
        public Linea(String c, int u, BigDecimal p) {
            numero = numLineasFactura + 1; // Acceso a miembro de instancia de la clase externa
            concepto = c;
            unidades = u;
            precio = p;           
        }

        /**
         * 
         * @return Cadena con el contenido de un objeto
         */
        @Override
        public String toString() {
            return "Linea{" + "numero=" + getNumero() + ", concepto=" + getConcepto() + 
                    ", unidades=" + getUnidades() + ", precio=" + getPrecio() + '}';
        }        
        
        /**
         * @return the numero
         */
        public int getNumero() {
            return numero;
        }

        /**
         * @param numero the numero to set
         */
        public void setNumero(int numero) {
            this.numero = numero;
        }

        /**
         * @return the concepto
         */
        public String getConcepto() {
            return concepto;
        }

        /**
         * @param concepto the concepto to set
         */
        public void setConcepto(String concepto) {
            this.concepto = concepto;
        }

        /**
         * @return the unidades
         */
        public int getUnidades() {
            return unidades;
        }

        /**
         * @param unidades the unidades to set
         */
        public void setUnidades(int unidades) {
            this.unidades = unidades;
        }

        /**
         * @return the precio
         */
        public BigDecimal getPrecio() {
            return precio;
        }

        /**
         * @param precio the precio to set
         */
        public void setPrecio(BigDecimal precio) {
            this.precio = precio;
        }
        
    } // class LineaFactura

    /**
     * El constructor por defecto genera una factura vacía, sin líneas
     */  
    public Factura() {
        fecha = new Date();
        numero = siguienteNumero++;
        importe = BigDecimal.valueOf(0);
        lineasFactura = new Linea[MAX_LINEAS_FACTURA];
        numLineasFactura = 0;
    }
    
    /**
     * Agrega una línea a la factura actual
     * 
     * @param l Objeto {@link Linea} con la línea a agregar a la factura
     */
    public void anadeLinea(Linea l) {
        getLineasFactura()[numLineasFactura++] = l;
        actualizaImporte();
    }

    /**
     * Agrega una línea a la factura actual
     * 
     * @param concepto Concepto de la línea
     * @param unidades Número de unidades
     * @param precio  Precio unitario
     */
    public void anadeLinea(String concepto, int unidades, BigDecimal precio) {
        anadeLinea(new Linea(concepto, unidades, precio));
    }

    private void actualizaImporte() {
        setImporte(new BigDecimal("0"));
        for(var indice = 0; indice < numLineasFactura; indice++)
            setImporte(getImporte().add(getLineasFactura()[indice].getPrecio()
                    .multiply(new BigDecimal(getLineasFactura()[indice]
                            .getUnidades()))));
    }

    /**
     * Convierte el objeto Factura en un String
     * 
     * @return Una cadena con toda la información de la factura
     */
    @Override
    public String toString() {
        var str = "Factura{" + "fecha=" + getFecha() + ", numero=" + getNumero() + 
                ", importe=" + getImporte() + ", lineasFactura=";
        
        for(var indice = 0; indice < numLineasFactura; indice++)
            str = str + getLineasFactura()[indice];
                
        return str + ", numLineasFactura=" + numLineasFactura + '}';
    }

    /**
     * Clase anidada estática que puede utilizarse independientemente de Factura
     * 
     * @author Francisco Charte
     * 
     */
    public static class Ticket {
        /** Atributo que mantiene la factura asociada al ticket */
        private Factura factura; 
        
        /**
         * El constructor permite generar un nuevo ticket aceptando como 
         * entrada toda la información necesaria
         * 
         * @param strConceptos Cadena con los conceptos separados por comas
         * @param importes  Importes de cada uno de los conceptos
         */
        public Ticket(String strConceptos, BigDecimal... importes) {
            String[] conceptos = strConceptos.split(",");
            int indice = 0;
            
            factura = new Factura();

            for(var concepto : conceptos) 
                factura.anadeLinea(concepto, 1, importes[indice++]);                         
        }

        @Override
        public String toString() {
            return "Ticket{" + "factura=" + factura + '}';
        }          
    }
    
}
