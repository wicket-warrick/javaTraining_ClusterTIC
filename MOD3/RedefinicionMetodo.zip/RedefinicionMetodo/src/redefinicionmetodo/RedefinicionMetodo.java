package redefinicionmetodo;

class Cuadrado {
    protected double alto;
    
    Cuadrado(double lado) {
        this.alto = lado;
    }
    
    double getArea() {
        return alto * alto;
    }
}

class Rectangulo extends Cuadrado {
    protected double ancho;
    
    Rectangulo(double alto, double ancho) {
        super(alto);
        this.ancho = ancho;
    }
    
    @Override
    double getArea() {
        return ancho * alto;
    }
}

public class RedefinicionMetodo {

    public static void main(String[] args) {
        var unCuadrado = new Cuadrado(5);
        var unRectangulo = new Rectangulo(5, 8);
        
        System.out.println("Cuadrado: " + unCuadrado.getArea() + 
                "\nRectángulo: " + unRectangulo.getArea());
    }
    
}
