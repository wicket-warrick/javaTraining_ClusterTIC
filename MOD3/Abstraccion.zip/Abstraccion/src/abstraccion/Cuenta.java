package abstraccion;

import java.math.BigDecimal;
import java.util.Date;

class Cuenta {
    // Constante pública accesible para todos
    public static final long MAX_NUM_CUENTA = Long.MAX_VALUE;
    
    // Atributos con el estado interno de cada cuenta, privados
    private long numero;
    private String nombre;
    private BigDecimal saldo;

    // Atributo protegido, accesible para subclases de esta
    protected Date ultimoMovimiento;

    // Atributos estáticos
    private static long siguienteCodigo = 1000L;
    private static long inicioClase;
    
    // Bloque de inicialización
    static {
        inicioClase = System.nanoTime();
        System.out.println("Clase Cuenta cargada " + inicioClase);
    }
    
    // Constructores de la clase con distintos parámemtros
    public Cuenta(long numero, String nombre, BigDecimal saldo) {
        this.numero = numero;
        this.nombre = nombre;
        this.saldo  = saldo;
    }

    public Cuenta(long numero, String nombre) {
        this(numero, nombre, new BigDecimal(0));
    }

    public Cuenta(String nombreCuenta) {
        numero = siguienteCodigo++;
        nombre = nombreCuenta;
        saldo = new BigDecimal(0);
    }

    // Constructor de copia
    public Cuenta(Cuenta cuenta) {
        this(cuenta.numero, cuenta.nombre, cuenta.saldo);
    }
    
    // Constructor por defecto
    public Cuenta() {
        this(Cuenta.siguienteCodigo, "Cuenta " + Cuenta.siguienteCodigo);
        Cuenta.siguienteCodigo++;
    }

    @Override
    public String toString() {
        return numero + ", " + nombre + ", " + saldo;
    }
    
    // Métodos de operación sobre una cuenta
    public BigDecimal cargo(BigDecimal importe) {
        saldo = saldo.subtract(importe);
        return saldo;
    }
    
    public BigDecimal abono(BigDecimal importe) {
        saldo = saldo.add(importe);
        return saldo;        
    }

    /**
     * @return the numero
     */
    public long getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(long numero) {
        this.numero = numero;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the saldo
     */
    public BigDecimal getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }
    
}
