package abstraccion;

public class Abstraccion {
    public static void main(String[] args) {
        Aplicacion.getInstance().run();
    }
    
}
