package abstraccion;

import java.math.BigDecimal;

public class Aplicacion {
    private static Aplicacion instancia; // Atributo privado con la instancia
    
    // Constructor privado solo accesible internamente
    private Aplicacion() {
        // Inicialización de la única instancia de la clase
        System.out.println("Instancia de Aplicacion creada");
    }
    
    // Método para acceder a la instancia de la clae
    public static Aplicacion getInstance() {
        if (instancia == null)
            instancia = new Aplicacion();

        return instancia;
    }
    
    // Ejecución de la aplicación
    public void run() {
        Cuenta banco = new Cuenta("Banco"),
               electricidad = new Cuenta("Electricidad");
        
        // Saldo inicial en el banco
        banco.abono(BigDecimal.valueOf(874.53));
        
        // Anotamos un recibo
        var importeRecibo = BigDecimal.valueOf(46.34);
        banco.cargo(importeRecibo);
        electricidad.abono(importeRecibo);
        
        System.out.println(banco + "\n" + electricidad); 
    }
}
