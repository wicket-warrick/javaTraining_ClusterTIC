package singleton;

public class Singleton {

    public static void main(String[] args) {
        Aplicacion.getInstance().run();
    }
    
}
