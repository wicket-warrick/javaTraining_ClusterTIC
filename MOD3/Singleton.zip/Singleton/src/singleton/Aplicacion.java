package singleton;

public class Aplicacion {
    private static Aplicacion instancia; // Atributo privado con la instancia
    
    // Constructor privado solo accesible internamente
    private Aplicacion() {
        // Inicialización de la única instancia de la clase
        System.out.println("Instancia de Aplicacion creada");
    }
    
    // Método para acceder a la instancia de la clae
    public static Aplicacion getInstance() {
        if (instancia == null)
            instancia = new Aplicacion();

        return instancia;
    }
    
    public void run() {
        System.out.println("Aplicación en ejecución");
    }
}
