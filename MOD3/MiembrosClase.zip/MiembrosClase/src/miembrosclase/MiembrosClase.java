package miembrosclase;

/*
  Miembros que pueden definirse en una clase
*/
public class MiembrosClase {
    // Interfaces 
    interface Calculadora {
        int suma(int a, int b);
        int diferencia(int a, int b);
    }
    
    // Clases anidadas
    class CalculadoraSimple implements Calculadora {
        @Override
        public int suma(int a, int b) {
            return a + b;
        }

        @Override
        public int diferencia(int a, int b) {
            return a - b;
        }   
    }
    
    // Constantes y variables
    static final int MAX_OPERACIONES = 1_000_000;
    int numOperaciones;
    
    // Constructores
    MiembrosClase() {
        numOperaciones = 0;
    }
    
    // Métodos
    void run() {
        System.out.println("Aplicación en funcionamiento");
    }
    
   
    public static void main(String[] args) {
        (new MiembrosClase()).run(); 
        
    }
    
}
