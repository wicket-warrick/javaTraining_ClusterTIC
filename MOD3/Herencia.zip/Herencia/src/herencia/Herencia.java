package herencia;

import java.util.Objects;

sealed class Punto permits Circulo {
    private Long posX, posY, posZ;

    public Punto(Long x, Long y, Long z) {
        posX = x;
        posY = y;
        posZ = z;
    }
    
    public Punto(String stringValue) {
        int begin = stringValue.indexOf('{') + 1,
            end   = stringValue.indexOf('}') ;
        
        String[] values = stringValue
                    .substring(begin, end)
                    .split(",");
        
        posX = Long.valueOf(values[0]);
        posY = Long.valueOf(values[1]);
        posZ = Long.valueOf(values[2]);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj != null && obj instanceof Punto) {
            Punto p = (Punto ) obj;
            
            return p.posX.equals(this.posX) &&
                   p.posY.equals(this.posY) &&
                   p.posZ.equals(this.posZ);
        } 
        
        return false;             
    }

    @Override
    public int hashCode() {
        return Objects.hash(posX, posY, posZ);
    }

    @Override
    public String toString() {
        return getClass().getName() + "{" + posX + "," + posY + "," + posZ + "}";
    }
    
    // Método que genera un objeto Punto a partir de una cadena
    static public Punto valueOf(String stringValue) {
        return new Punto(stringValue);
    }
    /**
     * @return the posX
     */
    public Long getPosX() {
        return posX;
    }

    /**
     * @param posX the posX to set
     */
    public void setPosX(Long posX) {
        this.posX = posX;
    }

    /**
     * @return the posY
     */
    public Long getPosY() {
        return posY;
    }

    /**
     * @param posY the posY to set
     */
    public void setPosY(Long posY) {
        this.posY = posY;
    }

    /**
     * @return the posZ
     */
    public Long getPosZ() {
        return posZ;
    }

    /**
     * @param posZ the posZ to set
     */
    public void setPosZ(Long posZ) {
        this.posZ = posZ;
    }
}

final class Circulo extends Punto {
    private Long radio;
    
    public Circulo(Long x, Long y, Long z, Long r) {
        super(x, y, z);
        radio = r;
    }

    @Override
    public String toString() {
        return super.toString() + ", " + radio;
    }    
    
    /**
     * @return the radio
     */
    public Long getRadio() {
        return radio;
    }

    /**
     * @param radio the radio to set
     */
    public void setRadio(Long radio) {
        this.radio = radio;
    }
}

public class Herencia {

    static void muestra(Punto objeto) {}
    
    public static void main(String[] args) {
        var unCirculo = new Circulo(2l, 6l, 14l, 10l);
        muestra(unCirculo);
        muestra(new Punto(1L,2L,3L));
        
        System.out.println(unCirculo);
        
        Punto unPunto = Punto.valueOf(unCirculo.toString()),
              otroPunto = (Punto ) unCirculo;

        System.out.println((unPunto == otroPunto) + " - " + unPunto.equals(otroPunto));
        System.out.println(unPunto.hashCode() + ", " + (new Punto(1L,2L,3L)).hashCode());
    }

}
