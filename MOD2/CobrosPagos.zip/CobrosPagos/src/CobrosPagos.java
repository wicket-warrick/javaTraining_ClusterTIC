
import java.math.BigDecimal;
import java.util.Date;
import java.util.Scanner;

public class CobrosPagos {
    // Opciones que ofrece el programa
    enum Opcion { COBRO, PAGO, MOVIMIENTOS, SALIR };
    
    // Tipos de movimientos en la cuenta
    enum TipoMovimiento { CARGO, ABONO };
    
    // Datos de un movimiento
    final class Movimiento {
        Date fechaRegistro;
        TipoMovimiento tipo;
        String concepto;
        BigDecimal importe;
        
        @Override
        public String toString() {
            return tipo.name() + " el " + fechaRegistro + 
                   " por " + importe + " euros. '" + concepto + "'";
        }
    }
    
    final static int MAX_MOVIMIENTOS = 1024; // Número máximo de movimientos
    
    // Vector que guardará los datos del programa
    Movimiento[] movimientos = new Movimiento[MAX_MOVIMIENTOS];
    // Movimientos anotados en el vector
    int numMovimientos = 0; 
    
    // Bucle principal de la aplicación
    void bucleApp() {
        Opcion opcion;
        
        do {
            muestraListaOpciones();
            opcion = solicitaOpcion();
            
            switch(opcion) {
                case COBRO, PAGO -> anotaMovimiento(
                        opcion == Opcion.COBRO ?
                                TipoMovimiento.ABONO :
                                TipoMovimiento.CARGO);
                case MOVIMIENTOS -> listaMovimientos();
            } 
        } while (opcion != Opcion.SALIR);
    }
    
    // Muestra la lista de opciones disponibles
    void muestraListaOpciones() {
        for(Opcion unaOpcion : Opcion.values())
            System.out.printf("\t%d -> %s\n", unaOpcion.ordinal(), unaOpcion.name());
    }
    
    // Solicita al usuario la opción que quiere ejecutar
    Opcion solicitaOpcion() {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        
        System.out.print("\nIntroduce el número de opción a ejecutar: ");
        opcion = scanner.nextInt();
        
        return Opcion.values()[opcion];
    }

    // Anota un nuevo movimiento
    void anotaMovimiento(TipoMovimiento tipo) {
        Scanner scanner = new Scanner(System.in);
        
        movimientos[numMovimientos] = new Movimiento();
        movimientos[numMovimientos].tipo = tipo;
        movimientos[numMovimientos].fechaRegistro = new Date();
        
        System.out.print("Concepto: ");
        movimientos[numMovimientos].concepto = scanner.nextLine();
        
        System.out.print("Importe: ");
        movimientos[numMovimientos].importe = new BigDecimal(scanner.next());
        
        System.out.println("\nMovimiento anotado");
        numMovimientos++;
    }
    
    // Muestra la lista de movimientos actual
    void listaMovimientos() {
        System.out.println();
        for(var indice = 0; indice < numMovimientos; indice++)
            System.out.println(movimientos[indice]);
        System.out.println();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        (new CobrosPagos()).bucleApp();
    }
}
