
import java.util.Date;

public class TiposEstructurados {
    // Enumeración con los meses
    enum Mes {
        ENERO, FEBRERO, MARZO, ABRIL, MAYO, JUNIO, JULIO,
        AGOSTO, SEPTIEMBRE, OCTUBRE, NOVIEMBRE, DICIEMBRE
    }
 
    // Enumeración con los brillos de un objeto celeste  
    enum Intensidad {
        CEGADOR, BRILLANTE, VISIBLE, APAGADO, INVISIBLE
    }
    // Estructura de datos para almacenar la información
    // de un sistema solar
    static final class SistemaSolar {
        String nombre;
        Intensidad brillo;
        int numEstrellas;
        int numPlanetas;
        double diametroUA;
        boolean hayVida;
        Date fechaRegistro;
        
        @Override
        public String toString() {
            return "Sistema solar " + nombre + 
                   " con brillo " + brillo.name() +
                   "\nTiene " + numEstrellas + 
                   " estrellas y " + numPlanetas + " planetas\n" +
                   "Su diámetro es de " + diametroUA + 
                   " UAs y se registró el " + fechaRegistro;
        }
    }

    public static void main(String[] args) {
        // Tres constantes
        final int NUM_MESES = 12;
        final int DIAS_AÑO = 365;
        final int NUM_POBLACIONES = 50;
        
        // Distintas formas de inicializar un vector
        int[] diasMes = new int[NUM_MESES],
              muestraEdades = {19, 32, 26, 54, 38};      
        // Vector bidimensional
        float[][] pluviometria = new float[DIAS_AÑO][NUM_POBLACIONES];

        // Acceso a un elemento de la matriz
        diasMes[Mes.ENERO.ordinal()] = 31;
        pluviometria[34][Mes.DICIEMBRE.ordinal()] = 12.6f;
        
        // Obtenemos el número de elementos de un vector
        System.out.println("Número de elementos = " + muestraEdades.length);

        // Los vectores pueden obtenerse a partir de distintas operaciones
        String nombreCurso = "Iniciación a Java";
        // Separamos la cadena varias partes usando el espacio como separador
        String[] partesCadena = nombreCurso.split(" ");
        
        // Mostramos el número de elementos obtenidos y último elemento 
        // del vector de cadenas 
        System.out.println(
                "Número de elmentos: " + partesCadena.length +
                "\nÚltima subcadena: " + partesCadena[partesCadena.length-1]
        );

        // Uso de la estructura de datos SistemaSolar
        SistemaSolar unSistemaSolar = new SistemaSolar();
        
        unSistemaSolar.nombre = "Carinae B21";
        unSistemaSolar.brillo = Intensidad.VISIBLE;
        unSistemaSolar.numEstrellas = 2;
        unSistemaSolar.numPlanetas = 1;
        unSistemaSolar.diametroUA = 7.6;
        unSistemaSolar.hayVida = false;
        unSistemaSolar.fechaRegistro = new Date();
        
        // Vector de referencias a objetos de tipo SistemaSolar
        SistemaSolar[] sistemas = new SistemaSolar[10];
        
        sistemas[0] = new SistemaSolar(); // Creamos un objeto
        sistemas[0].nombre = "Sistema solar local";
        sistemas[0].brillo = Intensidad.BRILLANTE;
        sistemas[0].numEstrellas = 1;
        sistemas[0].numPlanetas = 8;
        sistemas[0].diametroUA = 30.1;
        sistemas[0].hayVida = true;
        sistemas[0].fechaRegistro = new Date();

        System.out.println(unSistemaSolar);
        System.out.println(sistemas[0]);
    }
    
}