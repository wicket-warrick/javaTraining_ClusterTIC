
import java.util.Scanner;
import java.util.stream.Stream;

public class EstructurasControl {
    enum Intensidad {
        CEGADOR, BRILLANTE, VISIBLE, APAGADO, INVISIBLE
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);    
        int edad;
        char opcion;
        Intensidad Luna = Intensidad.BRILLANTE;
        int[] muestraEdades = {19, 32, 26, 54, -1, 38};
        
        System.out.print("Introduce una edad en años: ");
        edad = scanner.nextInt();

        // Condicional múltiple con if
        if (edad <= 2)
            System.out.println("Bebé");
        else if (edad <= 12)
            System.out.println("Niñez");
        else if (edad < 20)
            System.out.println("Adolescencia");
        else
            System.out.println("Adulto");

        do {
            System.out.print(
                    "L -> Leer archivo de datos\n" +
                    "E -> Editar ficha\n" +
                    "I -> Imprimir listado\n" +
                    "G -> Guardar datos\n" +
                    "S -> Salir de la aplicación\n\n" +
                    "\t\tElige una opción: ");
            opcion = scanner.next().charAt(0);
        
            if ("LlEeIiGgSs".indexOf(opcion) == -1)
                continue;
            
            // Condicional múltiple con operando común
            if (opcion == 'L' || opcion == 'l')
                System.out.println("Leyendo archivo");
            else if (opcion == 'E' || opcion == 'e')
                System.out.println("Editando ficha");
            else
                System.out.println("Opción no reconocida");

            // Mismo condicional anterior con switch
            switch (opcion) {
                case 'L', 'l' -> System.out.println("Leyendo archivo");
                case 'E', 'e' -> System.out.println("Editando ficha");
                default -> System.out.println("Opción no reconocida");
            }
        } while(opcion != 'S' && opcion != 's');
        
        // Switch con un tipo enumerado
        switch (Luna) {
            case CEGADOR:
            case BRILLANTE:
                System.out.println("Astro importante");
                break;
            case VISIBLE:
            case APAGADO:
                System.out.println("Astro poco importante");
                break;
            case INVISIBLE:
            default:
                System.out.println("No visible");
        }
        // Condición con parte else engañosa por el sangrado
        if ("LlGg".indexOf(opcion) >= 0) 
            if (opcion == 'l' || opcion == 'L')
                System.out.println("Lectura");
        else
            System.out.println("Opción no de E/S");
        
        // Bucle por contador clásico
        for (var indice = 0; indice < muestraEdades.length; indice++)
            System.out.println(muestraEdades[indice]);

        // Bucle que recorre los elementos del vector
        for (var unaEdad : muestraEdades) {
            if (unaEdad < 0)
                break;
            
            System.out.println(unaEdad);
        }

        // Suma de todos los valores válidos en muestraEdades
        double suma = 0, nDatos = 0;
        for (var unaEdad : muestraEdades) {
            if (unaEdad < 0)
                continue;
            
            nDatos++;
            suma += unaEdad;
        }
        System.out.println("La edad promedio es " + suma / nDatos + " años");
        
        double[] datos = {5.4, 32.4, 53.1, 13.3};
        System.out.println(
                "Promedio = " + media(5.4, 32.4, 53.1, 13.3) + "\n" +
                "Promedio2 = " + media(datos));
    }

    // Métodos sobrecargados
    static double media(Double ... datos) {
        return media(Stream.of(datos).mapToDouble(Double::doubleValue).toArray());
    }
    
    static double media(double[] datos) {
       double suma = 0;

       for(double dato : datos)
          suma += dato;

       return suma / datos.length;       
    }
}
